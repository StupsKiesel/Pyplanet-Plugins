from pyplanet.apps.config import AppConfig
from pyplanet.apps.custom.chatsymbols.toolbar import ToolbarPlayer



class Player(AppConfig):
	game_dependencies = ['trackmania', 'shootmania']
	app_dependencies = ['core.maniaplanet']

	def __init__(self, *args, **kwargs):
		super().__init__(*args, **kwargs)

		self.toolbar = ToolbarPlayer(self)


	async def on_start(self):
		await self.toolbar.on_start()

